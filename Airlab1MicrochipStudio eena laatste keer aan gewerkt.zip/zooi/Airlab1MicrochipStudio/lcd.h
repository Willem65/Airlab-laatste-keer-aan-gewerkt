
#ifndef __LCD_H__
#define __LCD_H__


void SetupLCD(void);

void SetLCD(int RS, char *Buffer);

#endif