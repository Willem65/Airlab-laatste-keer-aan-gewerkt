#ifndef __DELAY_H__
#define __DELAY_H__

void Delay(int Tijd);
void Delay_ms(int Tijd);

#endif

