#ifndef __EVENTS_H__
#define __EVENTS_H__


void DoEvent(unsigned int Event);



#endif